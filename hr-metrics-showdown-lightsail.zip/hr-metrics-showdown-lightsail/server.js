const fs = require('fs');
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const QRCode = require('qrcode');

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'game.json');
const GAME_CODE = process.env.GAME_CODE || 'HICV-2026';
const HOST_TOKEN = process.env.HOST_TOKEN || 'change-this-host-token';

const defaultState = {
  q: 0,
  teams: [],
  answers: {},
  revealed: false,
  gameStarted: false,
  scored: {},
  pointsByQuestion: {},
  winnerRevealed: false,
  questions: null
};

function readState() {
  try {
    return { ...defaultState, ...JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) };
  } catch {
    return { ...defaultState };
  }
}

let gameState = readState();
fs.mkdirSync(DATA_DIR, { recursive: true });

function writeState() {
  const tmp = `${STATE_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(gameState, null, 2));
  fs.renameSync(tmp, STATE_FILE);
}

function sanitizeState(candidate) {
  if (!candidate || typeof candidate !== 'object') return gameState;
  return {
    ...gameState,
    q: Number.isInteger(candidate.q) ? Math.max(0, candidate.q) : gameState.q,
    teams: Array.isArray(candidate.teams) ? candidate.teams.slice(0, 100).map(t => ({ name: String(t.name || '').trim().slice(0, 100), score: Number(t.score) || 0 })).filter(t => t.name) : gameState.teams,
    answers: candidate.answers && typeof candidate.answers === 'object' ? candidate.answers : gameState.answers,
    revealed: Boolean(candidate.revealed),
    gameStarted: Boolean(candidate.gameStarted),
    scored: candidate.scored && typeof candidate.scored === 'object' ? candidate.scored : {},
    pointsByQuestion: candidate.pointsByQuestion && typeof candidate.pointsByQuestion === 'object' ? candidate.pointsByQuestion : {},
    winnerRevealed: Boolean(candidate.winnerRevealed),
    questions: Array.isArray(candidate.questions) ? candidate.questions : gameState.questions
  };
}

const app = express();
const server = http.createServer(app);
const io = new Server(server, { serveClient: true });

app.disable('x-powered-by');
app.get('/health', (_req, res) => res.json({ ok: true, gameCode: GAME_CODE, teams: gameState.teams.length }));
app.get('/config', (_req, res) => res.json({ gameCode: GAME_CODE }));
app.get('/qr', async (req, res) => {
  try {
    const text = String(req.query.text || '').slice(0, 2000);
    if (!text) return res.status(400).json({ error: 'Missing text' });
    const png = await QRCode.toBuffer(text, { width: 600, margin: 2, errorCorrectionLevel: 'M' });
    res.type('png').send(png);
  } catch {
    res.status(400).json({ error: 'Unable to create QR code' });
  }
});
app.get('/', (_req, res) => res.redirect('/captain'));
app.get('/captain', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/host', (req, res) => {
  if (req.query.token !== HOST_TOKEN) return res.status(403).send('Host access denied. Use the host URL with the configured token.');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (_req, res) => res.redirect('/captain'));

io.on('connection', socket => {
  socket.emit('state:initial', gameState);
  socket.on('state:request', () => socket.emit('state:initial', gameState));
  socket.on('state:update', incoming => {
    gameState = sanitizeState(incoming);
    writeState();
    socket.broadcast.emit('state:changed', gameState);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`HR Metrics Showdown listening on port ${PORT} with game code ${GAME_CODE}`);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
