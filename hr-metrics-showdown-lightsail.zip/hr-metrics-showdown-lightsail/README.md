# HICV HR Metrics Showdown

Live team-building game for HR metrics. The host uses the shared screen, and captains join from phones. The application uses Socket.IO for synchronized game state and persists the game state to a JSON file on the server.

## Requirements

- AWS Lightsail Ubuntu instance
- Node.js 20 or newer
- A static IP address
- A DNS name pointing to the static IP
- TCP ports 22, 80, and 443 allowed in the Lightsail firewall
- A reverse proxy such as Nginx for HTTPS and WebSocket forwarding

For a small internal event, a 1 GB instance can work. A 2 GB Linux instance is recommended for comfortable administration and future growth.

## Local test

```bash
npm install
cp .env.example .env
npm start
```

Open `http://localhost:3000`. Open a second browser window or phone on the same reachable server to test the synchronized host and captain views.

## AWS Lightsail deployment

### 1. Create the instance

Create an Ubuntu 24.04 LTS Lightsail instance. Attach a static IP. In the Lightsail Networking tab, allow TCP ports 22, 80, and 443.

### 2. Connect over SSH and install software

```bash
sudo apt update && sudo apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx unzip
sudo npm install -g pm2
node --version
npm --version
```

### 3. Upload the application

From your computer, upload the project archive using SCP, or clone the project if it is stored in Git. Example with SCP:

```bash
scp hr-metrics-showdown-lightsail.zip ubuntu@YOUR_STATIC_IP:/home/ubuntu/
```

On Lightsail:

```bash
sudo mkdir -p /opt/hr-metrics-showdown /var/lib/hr-metrics-showdown
sudo chown -R ubuntu:ubuntu /opt/hr-metrics-showdown /var/lib/hr-metrics-showdown
unzip /home/ubuntu/hr-metrics-showdown-lightsail.zip -d /tmp/hrms
cp -R /tmp/hrms/hr-metrics-showdown-lightsail/. /opt/hr-metrics-showdown/
cd /opt/hr-metrics-showdown
npm ci --omit=dev
```

### 4. Configure the game

Edit `ecosystem.config.cjs` and set the game code you want displayed on the host screen. Then start the application:

```bash
cd /opt/hr-metrics-showdown
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup systemd
```

Run the command printed by `pm2 startup systemd`, then run `pm2 save` again.

Verify the application:

```bash
curl http://127.0.0.1:3000/health
```

### 5. Configure Nginx

Replace `YOUR_DOMAIN_HERE` in `nginx.conf` with your DNS name, such as `hrmetrics.example.com`. Then install the configuration:

```bash
sudo cp /opt/hr-metrics-showdown/nginx.conf /etc/nginx/sites-available/hr-metrics-showdown
sudo ln -s /etc/nginx/sites-available/hr-metrics-showdown /etc/nginx/sites-enabled/hr-metrics-showdown
sudo nginx -t
sudo systemctl reload nginx
```

If the default Nginx page appears, remove the default site:

```bash
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

### 6. Point DNS to Lightsail

Create an A record for your chosen hostname pointing to the Lightsail static IP. Wait for DNS propagation, then verify:

```bash
curl -I http://YOUR_DOMAIN_HERE
```

### 7. Enable HTTPS

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d YOUR_DOMAIN_HERE
```

Choose the option to redirect HTTP to HTTPS. Certbot will update Nginx and configure renewal.

Test renewal:

```bash
sudo certbot renew --dry-run
```

### 8. Operate the game

- Open `https://YOUR_DOMAIN_HERE` on the host computer.
- Display the host lobby and QR code.
- Captains scan the QR code and enter their team name.
- Confirm all teams appear in the host lobby.
- Click **Start Game**.
- Use the Question Bank to enter the correct answers and Round 2 comparison values.
- Use **Reveal Winner** after the Final Round.

## Useful maintenance commands

```bash
pm2 status
pm2 logs hr-metrics-showdown
pm2 restart hr-metrics-showdown
sudo systemctl status nginx
curl https://YOUR_DOMAIN_HERE/health
```

## Data and backup

The active game state is stored in `/var/lib/hr-metrics-showdown/game.json`. Back it up before changing the server:

```bash
sudo cp /var/lib/hr-metrics-showdown/game.json /var/lib/hr-metrics-showdown/game.json.backup
```

The current design is intended for one active game session at a time. Add authentication before exposing it broadly to the public internet.
