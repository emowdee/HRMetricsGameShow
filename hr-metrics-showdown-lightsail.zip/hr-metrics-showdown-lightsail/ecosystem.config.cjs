module.exports = {
  apps: [{
    name: 'hr-metrics-showdown',
    script: './server.js',
    cwd: '/opt/hr-metrics-showdown',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '256M',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      GAME_CODE: 'HICV-2026',
      DATA_DIR: '/var/lib/hr-metrics-showdown'
    }
  }]
};
